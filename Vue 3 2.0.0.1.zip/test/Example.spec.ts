import { expect, it } from "vitest";

it("Test if data is a function", () => {
    expect("hi").toBe("hi");
});
