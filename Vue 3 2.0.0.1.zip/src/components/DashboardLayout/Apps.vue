<template>
    <v-menu location="bottom center" offset="15">
        <template v-slot:activator="{ props }">
            <button v-bind="props">
                <v-icon>mdi-apps</v-icon>
            </button>
        </template>

        <div
            class="bg-white px-6 p-4 rounded-3xl border w-[300px] flex flex-col items-start justify-start"
        >
            jkbjnjnj
        </div>
    </v-menu>
</template>
