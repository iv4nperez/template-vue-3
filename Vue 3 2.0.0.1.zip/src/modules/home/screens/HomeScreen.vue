<template>
    <LayoutDashboard>
        Hello from route dynamic
        <router-link to="/exportadordedocumentos">
            ir a exportadordedocumentos
        </router-link>
    </LayoutDashboard>
</template>
<script setup lang="ts">
import LayoutDashboard from "../../../layouts/LayoutDashboard.vue";
</script>
