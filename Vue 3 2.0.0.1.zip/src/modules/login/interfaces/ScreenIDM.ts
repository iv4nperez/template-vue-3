export interface Screen {
    screenId: number | null;
    ScreenName: null | string;
    Order: null | string;
    order: number;
    ActionUrl: null | string;
    ParentScreen: null | string;
    ParentIcon: null | string;
    ParentOrder: null | string;
    Tooltip: null | string;
    ParentdId: number;
    Icon: null | string;
}
