<template>
    <div>
        descarga screen
        <router-link to="/home"> ir a home </router-link>
    </div>
</template>
<script setup lang="ts"></script>
