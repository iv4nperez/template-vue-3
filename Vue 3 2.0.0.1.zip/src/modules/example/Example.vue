<template>
    <LayoutDashboard> Example </LayoutDashboard>
</template>
