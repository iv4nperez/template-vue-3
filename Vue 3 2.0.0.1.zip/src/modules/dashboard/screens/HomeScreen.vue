<template>
    <div>Dhasbvoard screen</div>
</template>

<script setup lang="ts"></script>
