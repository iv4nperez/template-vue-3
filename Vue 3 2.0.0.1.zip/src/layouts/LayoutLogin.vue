<template>
    <v-app>
        <slot />
    </v-app>
</template>
