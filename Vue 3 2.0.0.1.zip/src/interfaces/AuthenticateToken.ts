export interface TokenInformation {
    accessToken: string;
    refreshToken: string;
    expiresIn: number;
}
